<template>  
  <div id="app">  
    <Login/>  
    <HospitalUsers />
    <HospitalList />  
    <HospitalDashboard />  
  </div>  
</template>  
  
<script>  
import Login from './components/LoginPage.vue'  
import HospitalUsers from './components/HospitalUsers.vue'  
import HospitalList from './components/HospitalList.vue'  
import HospitalDashboard from './components/HospitalDashboard.vue'  

export default {  
  name: 'App',  
  components: {  
    Login,  
    HospitalUsers,  
    HospitalList,
    HospitalDashboard
  }  
}  
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>

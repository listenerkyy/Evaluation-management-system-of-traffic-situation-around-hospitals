<template>  
  <div class="container mt-5">  
    <!-- ������ -->  
    <nav class="navbar navbar-expand-lg navbar-light bg-light">  
      <a class="navbar-brand" href="#">ҽԺ�ܱ߽�ͨ�������۹���ϵͳ</a>  
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">  
        <span class="navbar-toggler-icon"></span>  
      </button>  
      <div class="collapse navbar-collapse" id="navbarNav">  
        <ul class="navbar-nav">  
          <li class="nav-item">  
            <router-link to="/" class="nav-link active" aria-current="page">��ҳ</router-link>  
          </li>  
          <li class="nav-item">  
            <router-link to="/user-management" class="nav-link">�û�����</router-link>  
          </li>  
          <!-- ���������� -->  
        </ul>  
      </div>  
    </nav>  
  
    <!-- ҽԺ�б� -->  
    <div class="mt-4">  
      <h2>ҽԺ�б�</h2>  
      <div class="list-group">  
        <a href="#" class="list-group-item list-group-item-action flex-column align-items-start" v-for="hospital in hospitals" :key="hospital.id">  
          <div class="d-flex w-100 justify-content-between">  
            <h5 class="mb-1">{{ hospital.name }}</h5>  
            <small>{{ hospital.location }}</small>  
          </div>  
          <p class="mb-1">{{ hospital.date }}</p>  
          <small class="text-muted">{{ hospital.score }} ��</small>  
          <div class="d-flex w-100 justify-content-between">  
            <button class="btn btn-primary btn-sm me-2">�鿴����</button>  
            <button class="btn btn-secondary btn-sm">�༭</button>  
          </div>  
        </a>  
      </div>  
    </div>  
  </div>  
</template>  
  
<script setup>  
import { ref } from 'vue';  
  
const hospitals = ref([  
  { id: 1, name: '������ˮ̶ҽԺ', location: '������', date: '2024-07-16', score: 45 },  
  { id: 2, name: '������ѧ����ҽԺ', location: '������', date: '2024-07-16', score: 34 },  
  // ����ҽԺ����...  
]);  
</script>  
  
<style scoped>  
/* �����������һЩ�ض�������������ʽ */  
</style>
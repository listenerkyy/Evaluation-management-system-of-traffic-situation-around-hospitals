<template>  
  <div class="container mt-5">  
    <h2 class="text-center">ҽԺ�ܱ߽�ͨ�������۹���ϵͳ</h2>  
    <div class="row justify-content-center mt-4">  
      <div class="col-md-8">  
        <nav class="nav nav-tabs">  
          <a class="nav-item nav-link active" href="#">�û�����</a>  
          <a class="nav-item nav-link" href="#">ҽԺ��Ϣ����</a>  
          <a class="nav-item nav-link" href="#">����ί�ۺ�����</a>  
        </nav>  
        <div class="card mt-3">  
          <div class="card-header">  
            ҽԺ�б�  
          </div>  
          <div class="card-body">  
            <table class="table table-striped">  
              <thead>  
                <tr>  
                  <th>���</th>  
                  <th>ҽԺ����</th>  
                  <th>ҽԺ����</th>  
                  <th>ҽԺ����</th>  
                  <th>����</th>  
                </tr>  
              </thead>  
              <tbody>  
                <tr v-for="(hospital, index) in hospitals" :key="index">  
                  <td>{{ index + 1 }}</td>  
                  <td>{{ hospital.name }}</td>  
                  <td>{{ hospital.district }}</td>  
                  <td>{{ hospital.type }}</td>  
                  <td>  
                    <button class="btn btn-primary btn-sm">�༭</button>  
                    <button class="btn btn-danger btn-sm" @click="deleteHospital(index)">ɾ��</button>  
                  </td>  
                </tr>  
              </tbody>  
            </table>  
            <nav aria-label="Page navigation example">  
              <ul class="pagination">  
                <li class="page-item"><a class="page-link" href="#">Previous</a></li>  
                <li class="page-item"><a class="page-link" href="#">1</a></li>  
                <li class="page-item"><a class="page-link" href="#">2</a></li>  
                <li class="page-item"><a class="page-link" href="#">3</a></li>  
                <li class="page-item"><a class="page-link" href="#">Next</a></li>  
              </ul>  
            </nav>  
          </div>  
        </div>  
      </div>  
    </div>  
  </div>  
</template>  
  
<script>  
export default {  
  data() {  
    return {  
      hospitals: [  
        { name: 'ҽԺA', district: '��A', type: '�ۺ�ҽԺ' },  
        { name: 'ҽԺB', district: '��B', type: 'ר��ҽԺ' },  
        // ����ҽԺ����...  
      ],  
    };  
  },  
  methods: {  
    deleteHospital(index) {  
      // ʵ��ɾ���߼�������ֻ��ʾ��  
      this.hospitals.splice(index, 1);  
    },  
  },  
};  
</script>  
  
<style scoped>  
/* �������������CSS��ʽ */  
</style>
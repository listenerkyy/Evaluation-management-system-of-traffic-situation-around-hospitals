<template>  
  <div class="container mt-5">  
    <div class="row justify-content-center">  
      <div class="col-md-6">  
        <div class="card">  
          <div class="card-header">  
            <h3 class="text-center">ҽԺ�ܱ߽�ͨ�������۹���ϵͳ</h3>  
          </div>  
          <div class="card-body">  
            <form @submit.prevent="handleLogin">  
              <div class="mb-3">  
                <label for="username" class="form-label">�˺�</label>  
                <input type="text" class="form-control" id="username" v-model="loginForm.username" required>  
              </div>  
              <div class="mb-3">  
                <label for="password" class="form-label">����</label>  
                <input type="password" class="form-control" id="password" v-model="loginForm.password" required>  
              </div>  
              <button type="submit" class="btn btn-primary btn-block">��¼</button>  
            </form>  
          </div>  
        </div>  
      </div>  
    </div>  
  </div>  
</template>  
  
<script>  
export default {  
  data() {  
    return {  
      loginForm: {  
        username: '',  
        password: ''  
      }  
    }  
  },  
  methods: {  
    handleLogin() {  
      // ����������ӵ�¼�߼�������API����  
      console.log('��¼��Ϣ:', this.loginForm);  
      // ģ���¼�ɹ�  
      alert('��¼�ɹ���');  
    }  
  }  
}  
</script>  
  
<style scoped>  
/* ����������CSS��ʽ */  
</style>